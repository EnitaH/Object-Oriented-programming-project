package Package1GameDesign;

public interface IWeapon {
    String getName();
    int attack();
}

